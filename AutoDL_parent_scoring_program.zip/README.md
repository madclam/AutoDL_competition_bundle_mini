### This is the master phase scoring program for the AutoDL challenge

`evaluate.py` - is an example that gathers all the results of the children phases and put them into two files: scores.txt and detailed_results.html. The former contains the scores and duration to be shown on the leaderboard. The latter contains the detailed results (learning curves).

`metadata` - is a file that instructs Codalab what to do to execute the code.